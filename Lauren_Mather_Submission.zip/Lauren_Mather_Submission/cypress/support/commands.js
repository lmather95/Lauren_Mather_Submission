import { commandTimings } from 'cypress-timings'
commandTimings()
