/// <reference types="cypress" />

context('Assertions', () => {
	beforeEach(() => {
		cy.visit('/')
		cy.request('/')
			.should((response) => {
				expect(response.status).to.eq(200)
			})
		cy.url().should('eq', 'https://www.saucedemo.com/')

	})
	it('Performance Glitch User Experience', () => {
		describe('Log In As Performance Glitch User Is Delayed', () => {
			cy.get('.login_credentials').should('be.visible')
			cy.get('.login_password')
			cy.get('[data-test="username"]').type("performance_glitch_user")
			cy.get('[data-test="password"]').type("secret_sauce")
			cy.get('[data-test="login-button"]').click()
			//Below will cause test to fail due to Timeout as the website is delayed when this user Logs In
			cy.window().its('performance').invoke('measure', 'modalOpen').its('duration', {
				timeout: 0
            }).should('be.lessThan', 3000)
			cy.url().should('eq', 'https://www.saucedemo.com/inventory.html')
			//This test will not run due to previous failing test, if we did proceed to this test due to the delay in adding an item to a basket we would again see a failed test
		describe('Add Item To Basket Is Delayed', () => {
			cy.get('[data-test="add-to-cart-sauce-labs-fleece-jacket"]').click()
			cy.get('.shopping_cart_badge').should('have.text', '1')
			cy.window().its('performance').invoke('measure', 'modalOpen').its('duration', {
				timeout: 0
			}).should('be.lessThan', 3000)
		})


		})

	})
})