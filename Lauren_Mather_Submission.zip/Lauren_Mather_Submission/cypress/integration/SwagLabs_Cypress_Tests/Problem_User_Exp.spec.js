/// <reference types="cypress" />

context('Assertions', () => {
	beforeEach(() => {
		cy.visit('/')
		cy.request('/')
			.should((response) => {
				expect(response.status).to.eq(200)
			})
		cy.url().should('eq', 'https://www.saucedemo.com/')
	})

	it('Problem user can log in', () => {
		describe('Log Into Problem user account', () => {
			cy.get('.login_credentials').should('be.visible')
			cy.get('.login_password')
			cy.get('[data-test="username"]').type("problem_user")
			cy.get('[data-test="password"]').type("secret_sauce")
			cy.get('[data-test="login-button"]').click()
			cy.window().its('performance').invoke('measure', 'modalOpen').its('duration', {
				timeout: 0
			}).should('be.lessThan', 1000)
		})
		describe('Unable To Checkout If Form Is Incomplete', () => {
			cy.get('.shopping_cart_link').scrollIntoView().click()
			cy.get('[data-test="checkout"]').click()
			cy.get('.checkout_info').should('be.visible')
			cy.get('[data-test="continue"]').click()
			cy.get('[data-test="error"]').should('be.visible')
			cy.get('button[id="react-burger-menu-btn"]').click()
			cy.get('#inventory_sidebar_link').should('be.visible').click()
		})

//Expected failing tests below to indicate there is an issue

		//Image of item does not match on overview page
		describe('Selected Item Image Is The Same On Overview', () => {
			cy.get('#item_4_img_link > .inventory_item_img').should('have.attr', 'src', '/static/media/sl-404.168b1cce.jpg').click()
			cy.get('.inventory_details_img').should('have.attr', 'src', '/static/media/sl-404.168b1cce.jpg').click()
		})
		//Unable to add item to basket
		describe('Add Item To Basket', () => {
			cy.get('[data-test="add-to-cart-sauce-labs-fleece-jacket"]').click()
			cy.get('.shopping_cart_badge').should('have.text', '1')
		})
		//Unable to remove item from basket
		describe('Remove Item From Basket', () => {
			cy.get('[data-test="back-to-products"]').click()
			cy.get('[data-test="add-to-cart-sauce-labs-onesie"]').scrollIntoView().click()
			cy.get('[data-test="remove-sauce-labs-onesie"]')
		})
		//Unable to sort items
		describe('Sort Items', () => {
			cy.get('select[data-test="product_sort_container"]').select('hilo').should('have.value', 'hilo')
			cy.get('select[data-test="product_sort_container"]').select('lohi')
			cy.get('select[data-test="product_sort_container"]').select('za')
			cy.get('select[data-test="product_sort_container"]').select('az')
		})
		

	})
})