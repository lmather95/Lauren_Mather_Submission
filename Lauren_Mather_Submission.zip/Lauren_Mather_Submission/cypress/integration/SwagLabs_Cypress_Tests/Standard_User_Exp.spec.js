/// <reference types="cypress" />

context('Assertions', () => {
	beforeEach(() => {
		cy.visit('/')
		cy.request('/')
			.should((response) => {
				expect(response.status).to.eq(200)
			})
		cy.url().should('eq', 'https://www.saucedemo.com/')
	})
	it('Standard User Experience ', () => {
		describe('Log In Successfully', () => {
			cy.get('.login_credentials').should('be.visible')
			cy.get('.login_password')
			cy.get('[data-test="username"]').type("standard_user")
			cy.get('[data-test="password"]').type("secret_sauce")
			cy.get('[data-test="login-button"]').click()
			cy.window().its('performance').invoke('measure', 'modalOpen').its('duration', {
				timeout: 0
			}).should('be.lessThan', 1000)
		})
		describe('Add Items To Cart', () => {
			cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
			cy.get('[data-test="add-to-cart-sauce-labs-bolt-t-shirt"]').click()
			cy.get('[data-test="add-to-cart-sauce-labs-onesie"]').click()
			cy.get('.shopping_cart_badge').should('have.text', '3')
		})
		describe('Remove Items From Cart', () => {
			cy.get('[data-test="remove-sauce-labs-backpack"]').click()
			cy.get('.shopping_cart_badge').should('have.text', '2')
		})
		describe('Cancel Checkout And Continue Shopping', () => {
			cy.get('.shopping_cart_link').scrollIntoView().click()
			cy.url().should('include', '/cart')
			cy.get('[data-test="checkout"]').click()
			cy.get('.checkout_info').should('be.visible')
			cy.get('[data-test="cancel"]').click()
			cy.get('.title').should('have.text', 'Your Cart')
			cy.get('[data-test="continue-shopping"]').click()
			cy.get('.title').should('have.text', 'Products')
		})
		describe('Unable To Checkout If Form Is Incomplete', () => {
			cy.get('.shopping_cart_link').scrollIntoView().click()
			cy.get('[data-test="checkout"]').click()
			cy.get('.checkout_info').should('be.visible')
			cy.get('[data-test="continue"]').click()
			cy.get('[data-test="error"]').should('be.visible')
			cy.url().should('include', '/checkout-step-one')
        })
		describe('Successfully Checkout', () => {
			cy.get('[data-test="firstName"]').type("standard")
			cy.get('[data-test="lastName"]').type("user")
			cy.get('[data-test="postalCode"]').type("TEST01")
			cy.get('[data-test="continue"]').click()
			cy.get('.title').should('have.text', 'Checkout: Overview')
			cy.get('[data-test="finish"]').click()
			cy.get('.complete-header').should('have.text', 'THANK YOU FOR YOUR ORDER')
		})
		describe('Return To All Items', () => {
			cy.get('button[id="react-burger-menu-btn"]').click()
			cy.get('#inventory_sidebar_link').should('be.visible').click()
		})
		describe('Sort Items', () => {
			cy.get('select[data-test="product_sort_container"]').select('hilo')
			cy.get('select[data-test="product_sort_container"]').should('contain.value', 'hilo')
			cy.get('select[data-test="product_sort_container"]').select('lohi')
			cy.get('select[data-test="product_sort_container"]').should('contain.value', 'lohi')
			cy.get('select[data-test="product_sort_container"]').select('za')
			cy.get('select[data-test="product_sort_container"]').should('contain.value', 'za')
			cy.get('select[data-test="product_sort_container"]').select('az')
			cy.get('select[data-test="product_sort_container"]').should('contain.value', 'az')
		})
		describe('View Item Overview Page', () => {
			cy.get('#item_4_img_link > .inventory_item_img').click()
			cy.url().should('include', '/inventory-item.html?id=4')
			cy.get('[data-test="back-to-products"]').should('be.visible').click()
		})
		describe('Reset App State', () => {
			cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
			cy.get('button[id="react-burger-menu-btn"]').click()
			cy.get('#reset_sidebar_link').should('be.visible').click()
		})
		describe('Logout Of Standard User Account', () => {
			cy.get('#logout_sidebar_link').should('be.visible').click()
			cy.get('#login_button_container').should('be.visible')
			cy.url().should('eq', 'https://www.saucedemo.com/')
		})
	})
	it('Unable To Log In With Invalid Credentials', () => {
		describe('Fail To Log In With No Inputted Credentials', () => {
			cy.get('.login_credentials')
			cy.get('.login_password')
			cy.get('[data-test="login-button"]').click()
			cy.get('[data-test="error"]').should('be.visible')
		})
		describe('Fail To Log In With Invalid Credentials', () => {
			cy.get('.login_credentials')
			cy.get('.login_password')
			cy.get('[data-test="username"]').type("wrongUsername")
			cy.get('[data-test="password"]').type("wrongPassword")
			cy.get('[data-test="login-button"]').click()
		})
		describe('See Expected Error Message', () => {
			cy.get('[data-test="error"]').should('have.text', 'Epic sadface: Username and password do not match any user in this service')
		})
	})
})
