/// <reference types="cypress" />

context('Assertions', () => {
	beforeEach(() => {
		cy.visit('/')
		cy.request('/')
			.should((response) => {
				expect(response.status).to.eq(200)
			})
		cy.url().should('eq', 'https://www.saucedemo.com/')
	})
	it('Locked Out Users Are Unable To Log In And See Expected Error Message', () => {
		describe('fail to log in as locked out user', () => {
			cy.get('.login_credentials').should('be.visible')
			cy.get('.login_password')
			cy.get('[data-test="username"]').type("locked_out_user")
			cy.get('[data-test="password"]').type("secret_sauce")
			cy.get('[data-test="login-button"]').click()
		})
		describe('See Expected Locked Out Error Message', () => {
			cy.get('[data-test="error"]').should('have.text', 'Epic sadface: Sorry, this user has been locked out.')
		})

	})
})

